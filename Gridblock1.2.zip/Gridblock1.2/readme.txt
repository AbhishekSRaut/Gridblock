welcome to Gridblock!
Idea by Sakshi Amrutkar.
developed by Abhishek Raut.
note:
if you get security worning by windows, its a normal.
the windows 11, or windows 10 flags applications which do not having digital cirtificket as an un secure.
Ignore that worning, and enjoy the game! its just, safe!
we will try to varify this application soon, so it will not give that worning.
to start game, run Gridblock.exe
keyboard shortcuts:
c to check colors.
enter to play, and arros to navigate.
s to check how many turns left to play, 16 is max.
p to check possible moves.
t to check who's turn it is.